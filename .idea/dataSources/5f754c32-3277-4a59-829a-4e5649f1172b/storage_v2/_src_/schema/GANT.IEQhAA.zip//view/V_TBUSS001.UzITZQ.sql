create view V_TBUSS001 as
  (select t."PTNO",t."DSCA",t."PDAT",t."USID",t."UDAT",t."GROP",t."STA1",t."STA2",(select c.dsca from cbase000 c where c.usid = t.usid)unam,(select c.dsca from cbase009 c where c.grop = t.grop)gropnam from tbuss001 t)
/

