create view QPUR002_BAAN_DETIALS as
  select "COMP","DSCA","STA1" from cbase001
/

