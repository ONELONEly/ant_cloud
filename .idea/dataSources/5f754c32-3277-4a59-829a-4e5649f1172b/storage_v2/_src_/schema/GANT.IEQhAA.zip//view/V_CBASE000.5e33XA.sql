create view V_CBASE000 as
  (select c."USID",c."NAMA",c."IDAT",c."DEPT",c."SYSS",c."AARC",c."MAIL",c."PHO1",c."MOD1",(select c17.dsca from cbase017 c17 where c17.acco=c.offi)offi,c."TEAM",c."GROU",c."POST",c."AREA",c."EDUA",c."DEAC",c."PTYP",c."REAM",c."STA1",c."PAWD",c."STA2"
from Cbase000 c)
/

