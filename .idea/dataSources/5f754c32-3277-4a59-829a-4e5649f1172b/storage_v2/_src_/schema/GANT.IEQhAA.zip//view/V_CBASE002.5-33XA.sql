create view V_CBASE002 as
  (SELECT c."PONO",c."DSCA",c."STYP",c."PURL",(SELECT u.dsca FROM UTILL003 u where u.PTYP = c.STYP)stypnam FROM CBASE002 c)
/

