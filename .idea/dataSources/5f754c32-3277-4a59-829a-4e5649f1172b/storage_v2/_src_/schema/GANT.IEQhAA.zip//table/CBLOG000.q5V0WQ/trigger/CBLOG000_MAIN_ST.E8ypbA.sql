create trigger CBLOG000_MAIN_ST
  before insert
  on CBLOG000
  for each row
  BEGIN  IF :new.main IS NULL THEN SELECT Cblog000_main_seq.nextval into :new.main FROM dual; END IF; END Cblog000_main_ST;
/

